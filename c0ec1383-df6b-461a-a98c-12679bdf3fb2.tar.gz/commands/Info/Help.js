module.exports = ({
name: "Help",
code: `
$title[Help]
$description[
**Info Help**
ihelp
**Fun Help**
fhelp
**Badges**
badge]
$color[#8C51FF]
$footer[Swift.]
`});