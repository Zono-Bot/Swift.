module.exports = ({
name: "Info",
    code: ` 
$title[**INFO**
$description[<:swift:1124246727248072704> Swiftly Good.

Servers: $guildCount <:server:1124247424689508465>
Members I serve: $allMembersCount <:member:1124246687616073768>

**Bot Version**: *0 beta*
**Aoi.js Version**: *$packageVersion*
**Node Version**: *$nodeVersion*
**Host**: *NxgtHost*

**DEVS** <:dev:1124247360508284969>
adityaredflag
.brkt
alone.8828]
$color[#8C51FF]
$footer[Made with love.]
$addButton[1;NxgtHost;link;https://NxgtHost.com/;false;]`
})