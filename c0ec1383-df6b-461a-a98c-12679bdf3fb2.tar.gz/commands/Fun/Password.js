module.exports = ({
name: "password",
  code: `
$color[#8C51FF]
$sendDm[$toUppercase[||$randomString[$message]|| <:tick:1124247129938989106>;$authorID;false]
 $onlyIf[$message[1]<=100;<:error:1124247098171326535> 100 characters is the max!]
 $onlyIf[$message[1]>=5;<:error:1124247098171326535> 5 characters or more!]
 $onlyIf[$isNumber[$message[1]]==true;<:error:1124247098171326535> 12 characters or more!]
 $onlyIf[false!=$isUserDmEnabled;<:error:1124247098171326535> Your DMs are not open!]
 $title[<:tick:1124247129938989106> Sent!]
 $footer[https://zono.bloxy.pro]
`
})