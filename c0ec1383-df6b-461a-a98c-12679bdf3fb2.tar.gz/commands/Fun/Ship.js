module.exports = {
name: "ship",
code: `$image[https://agg-api.vercel.app/ship?avatar1=$userAvatar[$authorID]?size=2048&avatar2=$userAvatar[$findMember[$message[1;true]]?size=2048&background=https://wallpapercave.com/wp/wp5075298.jpg&number=$random[1;100]]
$argsCheck[>0;$onlyif[$userExists[$findUser[$message[1]]]==true;You have to mention someone! <:error:1124247098171326535>]
$onlyif[$userExists[$findUser[$message[1]]]==true;Please mention someone! <:ERROR:1124246758080389190>] 
$color[#8C51FF]
`}
