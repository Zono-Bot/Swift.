module.exports = ({
  name: "8ball",
  code: `
  $argsCheck[>0;You have to put question! <:error:1124247098171326535>]
  $title[:8ball: 8ball Game]
  $description[
  **Question:**
  > $message
  
  **Answer:**
  > $randomtext[Yes!;Yes;No;Nope;Nahh;I don't think so...;Ask Again;Wha?]

  ]
  $color[8C51FF]`
})