module.exports = ({
name: "meme",
code: `
$image[$getObjectProperty[url]]
$title[**$getObjectProperty[title]**]
$color[#8C51FF]
$description[<:member:1124246687616073768> **Author**: $getObjectProperty[author]]
$createObject[$JsonRequest[https://meme-api.com/gimme]
`
})