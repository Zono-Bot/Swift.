module.exports = {
    name: "eval",
    code: `
$ttile[\`\`\`$eval[$message;no]\`\`\`]
$onlyForIDs[983386510235680888;You may not use this command. <:error:1124247098171326535>]
$color[#8C51FF]

    `
}