module.exports = ({
 name: "ping",
  code: `
  $title[Ping]
  $description[Pong! 🏓]
  $addButton[1;$ping ms;success;ping;false]
  $color[8C51FF]
  `
})