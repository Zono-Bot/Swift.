module.exports = {
name: "ihelp",
code:`
$title[Info Help]
$description[
Info - Shows info about the bot
Avatar (@user) - Shows the avatar of a user
Help - Shows the help command
Ping - Shows the ping
Status - Shows the status of the bot
]
$color[#8C51FF]`}