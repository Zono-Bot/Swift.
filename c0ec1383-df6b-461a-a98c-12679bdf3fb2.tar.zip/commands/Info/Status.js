module.exports = {
    name: "status",
    $if: "old",
    code: `
    $sendMessage[$title[Bot status]
    $addField[Bot Status;$customEmoji[endreply] $if[$ping <= 100]
<:good_ping:1124247206837370920> Working fast
$elseIf[$ping <= 350]
<:good_ping:1124247206837370920> Working average
$endelseIf
$elseIf[$ping <= 620]
<:emoji_16:1120250112568987778> Working slow
$endelseIf
$elseIf[$ping => 760]
<:emoji_16:1120250112568987778> Working very slow
$endelseIf
$endIf]
    $addField[CPU Process;$customEmoji[endreply] \`$truncate[$cpu] percent\`;false]
    $addField[CPU Usage;$customEmoji[endreply] \`$truncate[$cpu[os]] percent\`;false]
    $addField[RAM Limit;$customEmoji[endreply] \`$truncate[$maxRam] megabytes\`;false]
    $addField[RAM Usage;$customEmoji[endreply] \`$truncate[$ram] megabytes\`;false]
    $addField[Delay;$customEmoji[endreply] \`$ping miliseconds\`;false]
    $addField[Latency;$customEmoji[endreply] \`$messagePing miliseconds\`;false]
    $color[#8C51FF]
    $cooldown[4s;<@$authorID>, a little too quick there.{extraOptions:{delete: 3s}}]
    ;false]
    $reply[$messageID;false]
    `
}

