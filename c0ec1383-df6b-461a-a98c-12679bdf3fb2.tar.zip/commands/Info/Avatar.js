module.exports = ({
    name: "avatar",
    code: `
    $author[1;$username;$userAvatar[$authorID]]
    $description[1;**Formats:**
[**\`Jpg\`**]($userAvatar[$findMember[$message[1;true]];2048;true;jpg]) | [**\`Png\`**]($userAvatar[$findMember[$message[1;true]];2048;true;png]) | [**\`Jpeg\`**]($userAvatar[$findMember[$message[1;true]];2048;true;jpeg]) | [**\`Webp\`**]($userAvatar[$findMember[$message[1;true]];2048;true;webp])]
    $image[1;$userAvatar[$findMember[$message[1;true]];2048]]
    $color[8C51FF]
`
})