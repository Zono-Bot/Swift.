module.exports = {
name: "Haruki",
nonPrefixed: "true",
code: `
$title[Oh? What's this?]
$description[**You found Haruki! <:adisgirl:1137005543630835782>**
See your badges with the .badges command 
$setUserVar[Haruki;<:adisgirl:1137005543630835782> Haruki]
$color[#8C51FF]`
}