module.exports = {
name: "badge",
aliases : "badges",
code:`
$title[Your Badges]
$description[$getUserVar[Haruki]
$color[#8C51FF]
`}