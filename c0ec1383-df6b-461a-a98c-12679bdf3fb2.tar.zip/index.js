const { AoiClient, LoadCommands } = require("aoi.js");

const bot = new AoiClient({
    token: "MTExOTk3NTA5NjU1MjAwMTcxNg.GsknAi.oFP0QZgR6Fw2vJdjABE01WSo8BjPlvibGT2saQ",
    prefix: ".",
    intents: ["Guilds", "GuildMessages", "MessageContent"],
    events: ["onMessage", "onInteractionCreate"],
    database: {
        type: "aoi.db",
        db: require("@akarui/aoi.db"),
        tables: ["main"],
        path: "/home/container/database/",
        extraOptions: {
            dbType: "KeyValue"
        }
    }
});

const loader = new LoadCommands(bot);
loader.load(bot.cmd, "/home/container/commands/")
require('./handler/variables.js')(bot);
//you can change this to any directory you want

bot.status({
    text: "Getting re-coded|NxgtHost.com",
    type: "PLAYING",
    time: 12
});