module.exports = (bot) => { 
 bot.variables({
     Haruki: " "
 });
}